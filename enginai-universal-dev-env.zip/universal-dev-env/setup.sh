#!/usr/bin/env bash
echo "🚀 Instalando dependências Python e Node.js..."
pip install --no-cache-dir -r requirements.txt
npm install
echo "✅ Ambiente pronto!"
